'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useState } from 'react'
import { motion } from 'framer-motion'
import { Facebook, Twitter, Instagram, Menu, X, ChevronRight } from 'lucide-react'

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

export default function AnuradhapuraPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-white">
      <header className="fixed top-0 left-0 right-0 z-50 bg-white bg-opacity-90 backdrop-blur-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-gray-800">Serendipity</Link>
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li><Link href="/" className="text-gray-600 hover:text-gray-900 transition-colors">Home</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">Destinations</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">About</Link></li>
              <li><Link href="#" className="text-gray-600 hover:text-gray-900 transition-colors">Contact</Link></li>
            </ul>
          </nav>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </header>

      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed inset-0 z-40 bg-white pt-20"
        >
          <nav className="container mx-auto px-4">
            <ul className="space-y-4">
              <li><Link href="/" className="text-2xl font-semibold text-gray-800 hover:text-gray-600 transition-colors">Home</Link></li>
              <li><Link href="#" className="text-2xl font-semibold text-gray-800 hover:text-gray-600 transition-colors">Destinations</Link></li>
              <li><Link href="#" className="text-2xl font-semibold text-gray-800 hover:text-gray-600 transition-colors">About</Link></li>
              <li><Link href="#" className="text-2xl font-semibold text-gray-800 hover:text-gray-600 transition-colors">Contact</Link></li>
            </ul>
          </nav>
        </motion.div>
      )}

      <main className="pt-16">
        <HeroSection />
        <SearchForm />
        <BestOfAnuradhapura />
        <ContactForm />
      </main>

      <footer className="bg-gray-100 py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl font-bold text-gray-800">Serendipity Travels</h2>
              <p className="text-gray-600 mt-2">Discover the beauty of Sri Lanka</p>
            </div>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors"><Facebook /></a>
              <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors"><Twitter /></a>
              <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors"><Instagram /></a>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-gray-600">
            © 2024 Serendipity Travels. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}

function HeroSection() {
  return (
    <section className="relative h-screen">
      <Image
        src="/placeholder.svg?height=1080&width=1920"
        alt="Anuradhapura Sunset"
        layout="fill"
        objectFit="cover"
        priority
      />
      <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-center items-center text-white">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-4 text-center"
        >
          Anuradhapura
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl md:text-2xl mb-8 text-center"
        >
          North Central Province | Sri Lanka&apos;s ancient city
        </motion.p>
      </div>
    </section>
  )
}

function SearchForm() {
  return (
    <div className="container mx-auto px-4 -mt-16 relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <form className="bg-white p-6 rounded-lg shadow-lg flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <Select>
              <option value="">Anuradhapura</option>
            </Select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <Select>
              <option value="">Duration</option>
            </Select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <Select>
              <option value="">When</option>
            </Select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <Input type="date" placeholder="Start Date" />
          </div>
          <Button type="submit" className="bg-red-500 hover:bg-red-600 text-white transition-colors min-w-[120px]">
            Search
          </Button>
        </form>
      </motion.div>
    </div>
  )
}

function BestOfAnuradhapura() {
  return (
    <section className="container mx-auto px-4 py-24">
      <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Best Of Anuradhapura</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <motion.div 
          className="relative rounded-lg overflow-hidden shadow-lg"
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.3 }}
        >
          <Image
            src="/placeholder.svg?height=400&width=600"
            alt="Anuradhapura Landscape"
            width={600}
            height={400}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent flex items-end p-6">
            <h3 className="text-white text-2xl font-bold">Explore Anuradhapura</h3>
          </div>
        </motion.div>
        <div className="flex flex-col justify-between">
          <div>
            <h3 className="text-2xl md:text-3xl font-bold mb-4">Sacred City Adventures: Explore Anuradhapura</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Set your sights on an unforgettable journey into Sri Lanka&apos;s ancient past. Anuradhapura, a UNESCO World Heritage site, invites you to explore its vast archaeological wonders. From towering dagobas to serene reservoirs, every corner tells a story of a civilization lost to time.
            </p>
          </div>
          <Button className="self-start bg-red-500 hover:bg-red-600 text-white transition-colors">
            Learn More <ChevronRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

function ContactForm() {
  return (
    <section className="bg-gray-100 py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
          <div className="p-8">
            <h2 className="text-3xl font-bold mb-6 text-center">Get in Touch</h2>
            <form>
              <div className="grid grid-cols-1 gap-6">
                <Input placeholder="Name" />
                <Input type="email" placeholder="Email" />
                <Input placeholder="Phone" />
                <Textarea placeholder="Message" className="h-32" />
                <Button className="bg-blue-500 hover:bg-blue-600 text-white transition-colors">
                  Send Message
                </Button>
              </div>
            </form>
            <p className="mt-6 text-sm text-gray-500 text-center">
              By submitting this form, you agree to our privacy policy and terms of service.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}